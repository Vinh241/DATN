import dotenv from "dotenv";
import { Config } from "../types";
import { Secret } from "jsonwebtoken";

dotenv.config();

const config: Config = {
  port: parseInt(process.env.PORT || "3000", 10),
  database: {
    host: process.env.DB_HOST || "localhost",
    port: parseInt(process.env.DB_PORT || "5432", 10),
    username: process.env.DB_USERNAME || "postgres",
    password: process.env.DB_PASSWORD || "postgres",
    database: process.env.DB_NAME || "bookstore",
  },
  jwt: {
    secret: (process.env.JWT_SECRET || "your-secret-key") as Secret,
    expiresIn: process.env.JWT_EXPIRES_IN || "24h",
  },
  cors: {
    enabled: process.env.CORS_ENABLED === "true",
    origins: process.env.CORS_ORIGINS?.split(",") || [
      "http://localhost:5100",
      "http://localhost:5173",
    ],
  },
};

export default config;
