import db from "../database/connection";
import { Product, GetProductsQuery } from "../types";

/**
 * Find all products with applied filters, sorting and pagination
 */
export const findAll = async (query: GetProductsQuery) => {
  const {
    page = 1,
    limit = 10,
    sortBy = "quantity_sold",
    sortOrder = "desc",
    categoryId,
    publisherId,
    publisherIds, // Add support for array of publisher IDs
    authorId,
    minPrice,
    maxPrice,
    search,
  } = query;

  // Convert to numbers
  const pageNum = Number(page);
  const limitNum = Number(limit);
  const offset = (pageNum - 1) * limitNum;

  // Build query
  const dbQuery = db("products")
    .select(
      "products.*",
      db.raw("authors.name as author_name"),
      db.raw("publishers.name as publisher_name"),
      db.raw("categories.name as category_name")
    )
    .leftJoin("authors", "products.author_id", "authors.id")
    .leftJoin("publishers", "products.publisher_id", "publishers.id")
    .leftJoin("categories", "products.publisher_id", "categories.id");

  // Apply filters
  if (categoryId) {
    dbQuery.where("products.category_id", categoryId);
  }
  console.log("query", query);
  console.log("pipeline", publisherId, publisherIds);

  // Handle publisherIds array or single publisherId
  if (publisherIds && Array.isArray(publisherIds) && publisherIds.length > 0) {
    dbQuery.whereIn("products.publisher_id", publisherIds);
  } else if (publisherId) {
    dbQuery.where("products.publisher_id", publisherId);
  }

  if (authorId) {
    dbQuery.where("products.author_id", authorId);
  }
  if (minPrice !== undefined) {
    dbQuery.where("products.price", ">=", minPrice);
  }
  if (maxPrice !== undefined) {
    dbQuery.where("products.price", "<=", maxPrice);
  }
  if (search) {
    dbQuery
      .whereRaw("LOWER(products.name) LIKE ?", [`%${search.toLowerCase()}%`])
      .orWhereRaw("LOWER(products.description) LIKE ?", [
        `%${search.toLowerCase()}%`,
      ]);
  }

  // Clone the query for count
  const countQuery = dbQuery.clone();

  // Fix: Clear the select clause and only count
  countQuery.clearSelect().count({ count: "*" });

  // Apply sorting and pagination
  const products = await dbQuery
    .orderBy(`products.${sortBy}`, sortOrder)
    .limit(limitNum)
    .offset(offset);

  // Get total count
  const [{ count }] = await countQuery;

  // Add images to products
  const productsWithImages = await addImagesToProducts(products);

  return {
    products: productsWithImages,
    total: Number(count),
  };
};

/**
 * Find product by ID
 */
export const findById = async (id: number): Promise<Product | null> => {
  const product = await db("products")
    .select(
      "products.*",
      db.raw("authors.name as author_name"),
      db.raw("publishers.name as publisher_name"),
      db.raw("COALESCE(AVG(reviews.rating), 0) as average_rating"),
      db.raw("COUNT(DISTINCT reviews.id) as review_count")
    )
    .leftJoin("authors", "products.author_id", "authors.id")
    .leftJoin("publishers", "products.publisher_id", "publishers.id")
    .leftJoin("reviews", "products.id", "reviews.product_id")
    .where("products.id", id)
    .groupBy("products.id", "authors.name", "publishers.name")
    .first();

  if (product) {
    // Get product images
    const images = await db("product_images")
      .select("*")
      .where("product_id", id)
      .orderBy("is_primary", "desc");

    product.images = images;
  }

  return product || null;
};

/**
 * Create a new product
 */
export const create = async (product: Partial<Product>): Promise<Product> => {
  // Extract product_images array from the product data if it exists
  const { product_images, ...productData } = product as Partial<Product> & {
    product_images?: Array<{ image_url: string; is_primary: boolean }>;
  };

  // Begin a transaction
  const trx = await db.transaction();

  try {
    // Insert product and get the new product ID
    const [newProduct] = await trx("products")
      .insert(productData)
      .returning("*");

    // If product_images array is provided, insert them
    if (
      product_images &&
      Array.isArray(product_images) &&
      product_images.length > 0
    ) {
      // Prepare image data for insertion
      const imagesData = product_images.map((image) => ({
        product_id: newProduct.id,
        image_url: image.image_url,
        is_primary: image.is_primary || false,
      }));

      // Insert all images
      await trx("product_images").insert(imagesData);
    }

    // Commit transaction
    await trx.commit();

    // Get complete product with images
    const completeProduct = await findById(newProduct.id);
    if (!completeProduct) {
      throw new Error(
        `Could not find product after creation with ID: ${newProduct.id}`
      );
    }
    return completeProduct;
  } catch (error) {
    // Rollback transaction on error
    await trx.rollback();
    throw error;
  }
};

/**
 * Update a product
 */
export const update = async (
  id: number,
  data: Partial<Product>
): Promise<Product | null> => {
  // Extract product_images array from the data if it exists
  const { product_images, ...productData } = data as Partial<Product> & {
    product_images?: Array<{ image_url: string; is_primary: boolean }>;
  };

  // Begin a transaction
  const trx = await db.transaction();

  try {
    // Update product data
    const [updatedProduct] = await trx("products")
      .where("id", id)
      .update(productData)
      .returning("*");

    // If no product found, return null
    if (!updatedProduct) {
      await trx.rollback();
      return null;
    }

    // If product_images array is provided, handle image updates
    if (
      product_images &&
      Array.isArray(product_images) &&
      product_images.length > 0
    ) {
      // First, delete existing images if we're replacing them
      await trx("product_images").where("product_id", id).delete();

      // Prepare image data for insertion
      const imagesData = product_images.map((image) => ({
        product_id: id,
        image_url: image.image_url,
        is_primary: image.is_primary || false,
      }));

      // Insert all new images
      await trx("product_images").insert(imagesData);
    }

    // Commit transaction
    await trx.commit();

    // Get complete product with updated images
    return await findById(id);
  } catch (error) {
    // Rollback transaction on error
    await trx.rollback();
    throw error;
  }
};

/**
 * Delete a product
 */
export const remove = async (id: number): Promise<boolean> => {
  // Begin a transaction
  const trx = await db.transaction();

  try {
    // Xóa các bản ghi liên quan trong các bảng con
    // 1. Xóa khỏi giỏ hàng
    await trx("cart_items").where("product_id", id).delete();

    // 2. Xóa các đánh giá của sản phẩm
    await trx("reviews").where("product_id", id).delete();

    // 3. Xóa các mục trong đơn hàng
    // Lưu ý: Nếu đơn hàng đã tồn tại, chúng ta có thể giữ lại thông tin sản phẩm trong order_items
    // Trong trường hợp thực tế, chúng ta thường không xóa order_items
    // Nhưng để giải quyết vấn đề khóa ngoại, chúng ta sẽ xóa chúng
    await trx("order_items").where("product_id", id).delete();

    // 4. Xóa các ảnh sản phẩm
    await trx("product_images").where("product_id", id).delete();

    // 5. Cuối cùng xóa sản phẩm
    const deleted = await trx("products").where("id", id).delete();

    // Commit transaction nếu mọi thứ thành công
    await trx.commit();

    return deleted > 0;
  } catch (error) {
    // Rollback transaction nếu có lỗi
    await trx.rollback();
    throw error;
  }
};

// Helper function to add images to products
async function addImagesToProducts(products: any[]): Promise<any[]> {
  if (products.length === 0) return products;

  // Get all product IDs
  const productIds = products.map((product) => product.id);

  // Fetch all images for these products in a single query
  const images = await db("product_images")
    .select("*")
    .whereIn("product_id", productIds)
    .orderBy("is_primary", "desc");

  // Create a map of product_id -> images[]
  const imagesByProductId = images.reduce((map, image) => {
    if (!map[image.product_id]) {
      map[image.product_id] = [];
    }
    map[image.product_id].push(image);
    return map;
  }, {});

  // Add images to each product
  return products.map((product) => ({
    ...product,
    images: imagesByProductId[product.id] || [],
  }));
}

/**
 * Find flash sale products (products with sale_price, ordered by lowest price)
 */
export const findFlashSaleProducts = async (
  page: number = 1,
  limit: number = 5
) => {
  const offset = (page - 1) * limit;

  // Build query for products with author and publisher join
  const productsQuery = db("products")
    .select(
      "products.*",
      db.raw("authors.name as author_name"),
      db.raw("publishers.name as publisher_name")
    )
    .leftJoin("authors", "products.author_id", "authors.id")
    .leftJoin("publishers", "products.publisher_id", "publishers.id")
    .whereNotNull("sale_price")
    .orderBy("sale_price", "asc")
    .limit(limit)
    .offset(offset);

  // Build query for count - modified to use a simpler count query
  const countQuery = db("products")
    .whereNotNull("sale_price")
    .count({ count: "*" });

  // Execute both queries
  const products = await productsQuery;
  const [{ count }] = await countQuery;

  // Add images to products
  const productsWithImages = await addImagesToProducts(products);

  return {
    products: productsWithImages,
    total: Number(count),
  };
};

/**
 * Find new products (newest products by created_at)
 */
export const findNewProducts = async (page: number = 1, limit: number = 5) => {
  const offset = (page - 1) * limit;

  // Build query for products with author and publisher join
  const productsQuery = db("products")
    .select(
      "products.*",
      db.raw("authors.name as author_name"),
      db.raw("publishers.name as publisher_name")
    )
    .leftJoin("authors", "products.author_id", "authors.id")
    .leftJoin("publishers", "products.publisher_id", "publishers.id")
    .orderBy("created_at", "desc")
    .limit(limit)
    .offset(offset);

  // Build query for count
  const countQuery = db("products").count({ count: "*" });

  // Execute both queries
  const products = await productsQuery;
  const [{ count }] = await countQuery;

  // Add images to products
  const productsWithImages = await addImagesToProducts(products);

  return {
    products: productsWithImages,
    total: Number(count),
  };
};

/**
 * Find bestseller products (products with highest quantity_sold)
 */
export const findBestsellerProducts = async (
  page: number = 1,
  limit: number = 5
) => {
  const offset = (page - 1) * limit;

  // Build query for products with author and publisher join
  const productsQuery = db("products")
    .select(
      "products.*",
      db.raw("authors.name as author_name"),
      db.raw("publishers.name as publisher_name")
    )
    .leftJoin("authors", "products.author_id", "authors.id")
    .leftJoin("publishers", "products.publisher_id", "publishers.id")
    .orderBy("quantity_sold", "desc")
    .limit(limit)
    .offset(offset);

  // Build query for count
  const countQuery = db("products").count({ count: "*" });

  // Execute both queries
  const products = await productsQuery;
  const [{ count }] = await countQuery;

  // Add images to products
  const productsWithImages = await addImagesToProducts(products);

  return {
    products: productsWithImages,
    total: Number(count),
  };
};

/**
 * Find products by IDs
 */
export const findByIds = async (ids: number[]): Promise<Product[]> => {
  // Build query for products with author and publisher join
  const products = await db("products")
    .select(
      "products.*",
      db.raw("authors.name as author_name"),
      db.raw("publishers.name as publisher_name"),
      db.raw("categories.name as category_name")
    )
    .leftJoin("authors", "products.author_id", "authors.id")
    .leftJoin("publishers", "products.publisher_id", "publishers.id")
    .leftJoin("categories", "products.category_id", "categories.id")
    .whereIn("products.id", ids);

  // Add images to products
  return addImagesToProducts(products);
};
